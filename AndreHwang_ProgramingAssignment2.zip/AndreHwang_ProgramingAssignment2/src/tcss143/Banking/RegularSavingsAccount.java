package tcss143.Banking;

/**
 * @author Andrew Hwang
 * 5/13/2023
 *
 * This method extends SavingsAccount and creats RegularSavingsAccount object.
 * Also, it implaments the logic for the methods in SavingsAccount
 * @version 1
 */
public class RegularSavingsAccount extends SavingsAccount {
    /**
     * This method creates the RegularSavingsAccount object with the passed in
     * accountID, type of account, and amountHold.
     * @param accountID
     * Parameter is a String and is the ID
     * @param Saving
     * Parameter is a String and is the account type
     * @param amountHold
     * Parameter is a double and is the amount the account holds
     */
    public RegularSavingsAccount(String accountID, String Saving, double amountHold) {
        super(accountID, Saving, amountHold);
        super.setSavingRate(0.01);
    }

    /**
     * This method overrides deposit and deposits the passed in amount to the
     * balance and the savings rate.
     * @param amountGive
     * Parameter is a double and is the amount need to be added from balance
     * @throws Exception
     * Throws an exception if the inputted value is 0 or less
     */
    @Override
    public void deposit(double amountGive) throws Exception {
        if (amountGive <= 0) {
            throw new Exception("Enter valid amount");
        } else {
            super.setBalance(super.getBalance() + amountGive + (amountGive * super.getSavingRate()));
        }
    }

}
