package tcss143.Banking;

import java.util.ArrayList;

/**
 * @author Andrew Hwang
 * 5/13/2023
 *
 * This class implements AccountActions, creates a bank customer object, and
 * implements the methods inside AccountActions.
 *
 * @version 1
 */
public class BankCustomer implements AccountActions {
    private String name;
    private ArrayList<BankAccount> bankAccounts;
    private ArrayList<Transaction> transactionList;

    /**
     * This method creates the BankCustomer object with the name given.
     * @param name
     * Parameter is a String and is the name of the customer
     */
    public BankCustomer(String name) {
        this.name = name;
        bankAccounts = new ArrayList<>();
        transactionList = new ArrayList<>();
    }

    /**
     * This method opens a new bank account depending on the type the customer
     * wants to create. Also, it checks if the account number is already taken,
     * or if the account type is incorrect.
     * @param accountId
     * Parameter is a String and is the desired account ID
     * @param amount
     * Parameter is an integer and is the amount the customer wants to put in
     * to the bank
     * @param typeOfAccount
     * Parameter is a String and is the type of account the customer wants to
     * open
     * @throws Exception
     * Throws and exception if the customer inputted a taken ID or an improper
     * account type
     */
    @Override
    public void openAccount(String accountId, double amount, String typeOfAccount) throws Exception {
        for (BankAccount bankAccount : bankAccounts) {
            if (bankAccount.getAccountID().equals(accountId) ||
                    bankAccount.getAccountType().equals(typeOfAccount)) {
                throw new IllegalArgumentException("Add another ID or a valid account type.");
            }
        }
        if(typeOfAccount.equalsIgnoreCase("checking")) {
            bankAccounts.add(new CheckingAccount(accountId, typeOfAccount, amount));
        }else if(typeOfAccount.equalsIgnoreCase("saving")) {
            bankAccounts.add(new RegularSavingsAccount(accountId, typeOfAccount, amount));
        }

    }

    /**
     * This method closes an account based on the entered account ID
     * @param accountId
     * Parameter is an integer and is the ID
     * @throws Exception
     * Throws an exception if the ID is not found
     */
    @Override
    public void closeAccount(String accountId) throws Exception {
        for (int i = 0; i < bankAccounts.size(); i++) {
            if (bankAccounts.get(i).getAccountID().equals(accountId)) {
                bankAccounts.remove(i);
                break;
            }else {
                throw new IllegalArgumentException("ID is not found.");
            }
        }

    }

    /**
     * This method preforms a transaction and stores it in an array list with
     * the values entered. It also checks if the given ID is in the bank and if
     * the given transaction is allowed.
     * @param accountId
     * Parameter is an integer and is the ID
     * @param amount
     * Parameter is an integer and is the amount the customer wants to put in
     * to the bank
     * @param typeOfTransaction
     * Parameter is a String and is the type of account the customer wants to
     * open
     * @throws Exception
     * Throws and exception if the customer inputted an ID is not found
     * or an improper account type
     */
    @Override
    public void makeTransaction(String accountId, double amount, String typeOfTransaction) throws Exception {
        boolean flag = false;
        for (BankAccount bankAccount : bankAccounts) {
            if (bankAccount.getAccountID().equals(accountId)) {
                transactionList.add(new Transaction(accountId, amount, typeOfTransaction));
                flag = true;
                if (typeOfTransaction.equalsIgnoreCase("debit")) {
                    bankAccount.withdraw(amount);
                    break;
                } else if (typeOfTransaction.equalsIgnoreCase("credit")) {
                    bankAccount.deposit(amount);
                    break;
                }else {
                    throw new IllegalArgumentException("Add valid transaction type");
                }
            }
        }
        if (!flag) {
            throw new IllegalArgumentException("Add valid ID");
        }
    }

    /**
     * This method prints out all the transactions made with the entered
     * ID, by checking through the list to find the transactions
     * with the ID. If it is found then it will store that transaction in
     * another array list and print that list out. If not it will throw an
     * error message.
     * @param accountId
     * Parameter is an integer and is the ID
     * @return
     * Return is an arraylist <Transaction> and is where the transactions are stored
     * @throws Exception
     * Throws an exception if the ID is not found
     */
    @Override
    public ArrayList<Transaction> printTransactionReport(String accountId) throws Exception {
        ArrayList<Transaction> displayList1 = new ArrayList<>();
        boolean detect = false;
        for (Transaction transaction : transactionList) {
            if (transaction.getAccountID().equals(accountId)) {
                displayList1.add(transaction);
                detect = true;
            }
        }
        if (!detect){
            throw new IllegalArgumentException("Enter a valid ID.");
        }
        return displayList1;
    }

    /**
     * This method prints all transactions.
     * @return
     * Return is an ArrayList<Transaction> and is where the transactions
     * are stored
     */
    @Override
    public ArrayList<Transaction> printTransactionReport() {
        ArrayList<Transaction> displayList2 = new ArrayList<>();
        displayList2.addAll(transactionList);
        return displayList2;
    }

    /**
     * This method returns all the accounts in the bank
     * @return
     * Return is an ArrayList<BankAccount> and is the list that holds all the
     * accounts
     */
    @Override
    public ArrayList<BankAccount> printAllAccounts() {

        return bankAccounts;
    }
}

