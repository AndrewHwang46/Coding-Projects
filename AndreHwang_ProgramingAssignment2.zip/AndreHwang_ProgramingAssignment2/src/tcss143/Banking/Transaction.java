package tcss143.Banking;

/**
 * @author Andrew Hwang
 * 5/13/2023
 *
 * This class creates the transaction methods and overrides the to String.
 * @version 1
 */
public class Transaction {
    private String accountID;
    private double transactionAmount;
    private String transactionType;

    /**
     * This method creates the transaction object with the passed in values.
     * @param accountID
     * Parameter is a String and is the ID
     * @param transactionAmount
     * Parameter is a double and is the amount of money imputed
     * @param transactionType
     * Parameter is a String and is the type of transaction
     */
    public Transaction(String accountID, double transactionAmount, String transactionType) {
        this.accountID = accountID;
        this.transactionAmount = transactionAmount;
        this.transactionType = transactionType;
    }

    /**
     * This method gets the ID.
     * @return
     * Return is a String and is the ID
     */
    public String getAccountID() {
        return accountID;
    }

    /**
     * This method overrides the toString and formats transactions
     * @return
     * Return is a String, and it is how the information is printed
     */
    @Override
    public String toString() {
        return accountID + " " + transactionType + " " + String.format("$%.2f", transactionAmount);
    }
}

