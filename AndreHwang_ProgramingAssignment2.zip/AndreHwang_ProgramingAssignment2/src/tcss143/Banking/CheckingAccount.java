package tcss143.Banking;

/**
 * @author Andrew Hwang
 * 5/13/2023
 *
 * This class extends BankAccount and creates the CheckingAccount object and
 * implaments the methods from BankAccount.
 * @version 1
 */
public class CheckingAccount extends BankAccount{
    /**
     * This method creates the CheckingAccount from the passed in accountID,
     * checking, and amountHold.
     * @param accountID
     * Parameter is a String and is the ID
     * @param Checking
     * Parameter is a String and is the account type
     * @param amountHold
     * Parameter is a double and is the amount the account holds
     */
    public CheckingAccount(String accountID, String Checking, double amountHold) {
        super(accountID, "Checking", amountHold);
    }

    /**
     * This method overrides withdraw and withdraws the passed in amount from
     * the balance.
     * @param amountTake
     * Parameter is a double and is the amount needed to be removed from balance
     * @throws Exception
     * Throws an exception if the inputted value is 0 or less
     * */
    @Override
    public void withdraw(double amountTake) throws Exception {
        if (super.getBalance() - amountTake < 0){
            throw new Exception("Insufficient Balance");
        } else {
            super.setBalance(super.getBalance() - amountTake);
        }
    }

    /**
     * This method overrides deposit and deposits the passed in amount to the
     * balance
     * @param amountGive
     * Parameter is a double and is the amount need to be added from balance
     * @throws Exception
     * Throws an exception if the inputted value is 0 or less
     */
    @Override
    public void deposit(double amountGive) throws Exception {
        if (amountGive <= 0) {
            throw new Exception("Add valid amount of money");
        } else {
            super.setBalance(super.getBalance() + amountGive);
        }
    }
}

