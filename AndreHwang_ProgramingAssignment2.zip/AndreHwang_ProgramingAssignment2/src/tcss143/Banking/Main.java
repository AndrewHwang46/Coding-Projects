package tcss143.Banking;
import java.util.Scanner;

/**
 * @author Andrew Hwang
 * 5/13/2023
 *
 * This class is where everything is implimented and tested.
 * @version 1
 */
public class Main {
    /**
     * This method is where everything is implemented and tested.
     * @param args
     * @throws Exception
     * Throws the exceptions found in the methods
     */
    public static void main(String[] args) throws Exception {
        BankCustomer alice = new BankCustomer("Alice");
        alice.openAccount("6251950",1000.00,"saving");
        alice.openAccount("7271953",1500.00,"Checking");
        alice.openAccount("9251959",2000.00,"saving");
        alice.closeAccount("6251950");
        alice.makeTransaction("7271953",10.00,"debit");
        alice.makeTransaction("7271953",100.00,"debit");
        alice.makeTransaction("7271953",50.00,"credit");
        alice.makeTransaction("9251959",5.00,"credit");
        alice.makeTransaction("9251959",50.00,"credit");
        alice.makeTransaction("9251959",60.00,"debit");
        System.out.println(alice.printTransactionReport("7271953"));
        System.out.println(alice.printTransactionReport());
        System.out.println(alice.printAllAccounts());

        BankCustomer Bob = new BankCustomer("Bob");
        Bob.openAccount("111111",1000.00,"saving");
        Bob.openAccount("222222",1500.00,"Checking");
        Bob.openAccount("333333",2000.00,"saving");
        Bob.closeAccount("111111");
        Bob.makeTransaction("222222",10.00,"debit");
        Bob.makeTransaction("222222",100.00,"debit");
        Bob.makeTransaction("222222",50.00,"credit");
        Bob.makeTransaction("333333",5.00,"credit");
        Bob.makeTransaction("333333",50.00,"credit");
        Bob.makeTransaction("333333",60.00,"debit");
        System.out.println(Bob.printTransactionReport("222222"));
        System.out.println(Bob.printTransactionReport());
        System.out.println(Bob.printAllAccounts());


        BankCustomer Charlie = new BankCustomer("Charlie");
        Charlie .openAccount("111112",1000.00,"saving");
        Charlie .openAccount("222221",1500.00,"Checking");
        Scanner userChoice = new Scanner(System.in);
        System.out.println("Select: 1. Make Transaction 2. Print Transactions" +
                "for Account 3.Print all transactions 4. Print all accounts 5. Exit");
        System.out.println("Enter your selection: ");
        int choice = userChoice.nextInt();
        if (choice == 1) {
            System.out.println("Enter your id, the amount," +
                    "and the type of transaction with just spaces inbetwee: ");
            String nextID = userChoice.next();
            double nextAmount = userChoice.nextDouble();
            String nextType = userChoice.next();
            Charlie.makeTransaction(nextID, nextAmount, nextType);

        }else if(choice == 2) {
            System.out.println("Enter your id");
            String nextID = userChoice.next();
            Charlie.printTransactionReport(nextID);
        }else if(choice == 3) {
            Charlie.printTransactionReport();
        }else if(choice == 4) {
            Charlie.printAllAccounts();

        }else if(choice == 5) {
            System.out.println("End");

        }
    }
}
