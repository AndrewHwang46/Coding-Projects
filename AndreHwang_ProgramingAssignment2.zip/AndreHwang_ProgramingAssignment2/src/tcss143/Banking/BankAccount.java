package tcss143.Banking;

/**
 * @author Andrew Hwang
 * 5/13/2023
 *
 * This method is an abstract and creates the BankAccount object.
 * @version 1
 */
public abstract class BankAccount {

    private String accountID;

    private String accountType;

    private double balance;

    /**
     * This method creates the BankAccount object with passed in values.
     * @param accountID
     * Parameter is a String and is the ID
     * @param accountType
     * Parameter is a String and is the type of account
     * @param balance
     * Parameter is a double and is the amount of money
     */
    public BankAccount(String accountID, String accountType, double balance) {
        this.accountID = accountID;
        this.accountType = accountType;
        this.balance = balance;
    }

    /**
     * This method gets the balance.
     * @return
     * Return is a double and is the balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * This method gets the ID.
     * @return
     * Return is a String and is the ID
     */
    public String getAccountID() {
        return accountID;
    }

    /**
     * This method get the account type.
     * @return
     * Return is a String and is the account type
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * This method sets balance with the passed in balance
     * @param balance
     * Parameter is a double and is the balance
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * This method formats the information then prints it out
     * @return
     * Return is a String and is the formatted information
     */
    public String toString() {
        return  accountID + " " + accountType + ": " + String.format("$%.2f", balance);
    }

    /**
     * This method is abstract method for withdraw.
     * @param amountTake
     * Parameter is a double and is the amount need to be removed from balance
     * @throws Exception
     */
    public abstract void withdraw(double amountTake) throws Exception;

    /**
     * This method is abstract method for deposit.
     * @param amountGive
     * Parameter is a double and is the amount need to be added from balance
     * @throws Exception
     */
    public abstract void deposit(double amountGive) throws Exception;
}
