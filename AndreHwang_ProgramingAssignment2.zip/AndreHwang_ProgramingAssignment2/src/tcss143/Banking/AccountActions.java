package tcss143.Banking;

import java.util.ArrayList;

/**
 * @author Andrew Hwang
 * 5/13/2023
 *
 * This class is an interface that holds the methods that allows you to open
 * and close an account, make and print transaction, and prints all accounts.
 *
 * @version 1
 */
public interface AccountActions {
    void openAccount(String accountId, double amount, String typeOfAccount) throws Exception;

    void closeAccount(String accountId) throws Exception;

    void makeTransaction(String accountId, double amount, String typeOfTransaction) throws Exception;

    ArrayList<Transaction> printTransactionReport(String accountId) throws Exception;

    ArrayList<Transaction> printTransactionReport();

    ArrayList<BankAccount> printAllAccounts();
}
