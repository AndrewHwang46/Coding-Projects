package tcss143.Banking;

/**
 * @author Andrew Hwang
 * 5/13/2023
 *
 * This class extends BankAccount and creates a SavingsAccount object. As well
 * as, implimenting the logic to the withdraw method from BankAcount.
 * @version 1
 */
public abstract class SavingsAccount extends BankAccount{
    private double savingRate = 0.0;

    /**
     * This method creates the SavingAccount method with the passed
     * accountID, type of account, and amountHold.
     * @param accountID
     * Parameter is a String and is the ID
     * @param Saving
     * Parameter is a String and is the account type
     * @param amountHold
     * Parameter is a double and is the amount the account holds
     */
    public SavingsAccount(String accountID, String Saving, double amountHold) {
        super(accountID, "Saving", amountHold);
    }

    /**
     * This method gets the saving rate.
     * @return
     * Return is a double and is the savings rate
     */
    public double getSavingRate() {
        return savingRate;
    }

    /**
     * This method sets the saving rate with the passed in saving rate.
     * @param savingRate
     * Paramter is a double and is the saving rate
     */
    public void setSavingRate(double savingRate) {
        this.savingRate = savingRate;
    }

    /**
     * This method overrides withdraw and withdraws the passed in amount from
     * the balance.
     * @param amountTake
     * Parameter is a double and is the amount needed to be removed from balance
     * @throws Exception
     * Throws an exception if the inputted value is 0 or less
     */
    @Override
    public void withdraw(double amountTake) throws Exception {
        if (super.getBalance() - amountTake < 0){
            throw new Exception("Insufficient Balance");
        } else {
            super.setBalance(super.getBalance() - amountTake);
        }
    }

    @Override
    public abstract void deposit(double amountGive) throws Exception;

}
