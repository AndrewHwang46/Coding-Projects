/**
 * @author Andrew Hwang
 *
 * This class file creates a book object and private felids that
 * hold the book title, author, publisher, genre, year published, and if the
 * book has been issues or not.
 *
 * 4/15/2023
 * @version 1
 */
public class Book {
    private String bookTitle;
    private String bookAuthor;
    private String bookPublisher;
    private int yearPublished;
    private String bookGenre;
    private boolean issueBook;

    /**
     * This method creates the book object by passing the book title,
     * author, publisher, year published, genre.
     *
     * @param bookTitle
     * @param bookAuthor
     * @param bookPublisher
     * @param yearPublished
     * @param bookGenre
     */
    public Book(String bookTitle, String bookAuthor, String bookPublisher,
                int yearPublished, String bookGenre) {
        this.bookTitle = bookTitle;
        this.bookAuthor = bookAuthor;
        this.bookPublisher = bookPublisher;
        this.yearPublished = yearPublished;
        this.bookGenre = bookGenre;
        this.issueBook = false;
    }

    /**
     * This method gets the title of the book.
     *
     * @return bookTitle
     */
    public String getBookTitle() {
        return bookTitle;
    }

    /**
     * This method gets the author of the book.
     *
     * @return bookAuthor
     */
    public String getBookAuthor(){
        return bookAuthor;
    }

    /**
     * This method gets the issued state of the book.
     *
     * @return issueBook
     */
    public boolean getIssueBook() {
        return issueBook;
    }

    /**
     * This method get the books publisher
     *
     * @return bookPublisher
     */
    public String getBookPublisher(){
        return bookPublisher;
    }

    /**
     * This method gets the year the book was published
     *
     * @return yearPublished
     */
    public int getYearPublished(){
        return yearPublished;
    }

    /**
     * This method gets the books genre
     *
     * @return bookGenre
     */
    public String getBookGenre(){
        return bookGenre;
    }

    /**
     * This changes the Issue state of the book.
     *
     * @param bookName
     */
    public void setIssueBook(boolean bookName) {
        this.issueBook = bookName;
    }
}

