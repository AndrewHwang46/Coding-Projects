/**
 * @author Andrew Hwang
 * This class files creates a library object and private fields that hold
 * the library address and name. As well as, books, three counters,
 * list the libaray's inventory.
 *
 * 4/15/2023
 * @version 1
 *
 */
public class Library {
    private String libraryAddress;
    private String libraryName;
    private Book book;
    private int tracker;
    private int count;
    private int returned;
    private Book[] libraryInventory = new Book[10];
    /**
     * This method creates the library object by passing library name
     * and address.
     *
     * @param libraryAddress
     * @param libraryName
     */
    public Library(String libraryAddress, String libraryName){
        this.libraryAddress = libraryAddress;
        this.libraryName = libraryName;
    }

    /**
     * This method gets the name of the library and then returns that said name.
     *
     * @return libraryName
     */
    public String getNameOfLibrary() {
        return libraryName;
    }

    /**
     * This method gets the address of the library and
     * then returns that said address.
     *
     * @return libraryAddress
     */
    public String printAddress(){
        return libraryAddress;
    }

    /**
     * This method prints the hours of operation of both libraries.
     */
    public static void printOpeningHours() {
        System.out.println("9 AM to 5 PM");
    }

    /**
     * This method creates a book object, and adds
     * the new book object into the library's inventory
     * and increments a tracker that keeps the count of how
     * many books are in the inventory.
     *
     * @param bookTitle
     * @param bookAuthor
     * @param bookPublisher
     * @param yearPublished
     * @param bookGenre
     */
    public void addBook(String bookTitle, String bookAuthor, String bookPublisher,
                        int yearPublished, String bookGenre) {
        this.book = new Book(bookTitle, bookAuthor,bookPublisher,
                yearPublished, bookGenre);
        this.libraryInventory[tracker] = this.book;
        this.tracker++;
    }

    /**
     * This method stores the title of each book in the inventory
     * to a string variable.Then that string variable gets returned.
     *
     * @return name
     */
    public String printInventory() {
        String name = "";
        for (int i = 0; i < tracker; i++ ){
            name += libraryInventory[i].getBookTitle() + "\n";
        }
        return name;
    }

    /**
     * This method searches the inventory for the inputted book title. Then
     * once found it prints out all the information of that book.
     *
     * First the title runs through a nested if loop to check if the book
     * is in the library. If it is then a flag is set to true if not the flag
     * remains false. Once out of the for loop the flag is inputted
     * into an if loop that prints the books information if true
     * and prints "Book not found" if false.
     *
     * @param bookName
     */
    public void search(String bookName) {
        boolean searching = false;
        for (int i = 0; i < tracker; i++) {

            if (bookName.equalsIgnoreCase(libraryInventory[i].getBookTitle())) {
                this.book = libraryInventory[i];
                searching = true;
            }
        }

        if (searching) {
            System.out.println("Book Title: " + book.getBookTitle());
            System.out.println("Book Author: " + book.getBookAuthor());
            System.out.println("Book Genre: " + book.getBookGenre());
            System.out.println("Book Publisher: " + book.getBookPublisher());
            System.out.println("Book Year: " + book.getYearPublished());

        } else {
            System.out.println("Book not found!");
        }
    }

    /**
     * This method issues the inputted Book.
     *
     * First the book is inputted into a nested if loop that makes sure that
     * the book is in the library's inventory. If true a flag is set to true.
     * Otherwise, it remains false. Then the flag is inputted into an if
     * loop. If the flag is true then the book is issued and then a counter
     * keeps count of the number of books issued. If the flag is false then
     * it prints out "Book not in the inventory".
     *
     * @param bookIssued
     */
    public void issueBook(String bookIssued){
        boolean take = false;
        for (int i = 0; i < tracker; i++) {

            if (bookIssued.equalsIgnoreCase(libraryInventory[i].getBookTitle())) {
                this.book = libraryInventory[i];
                take = true;
            }
        }
        if (take) {
            this.book.setIssueBook(true);
            count++;
        }else {
            System.out.println("Book not in the inventory. Cannot issue!");
        }
    }
    /**
     * This method returns the inputted Book.
     *
     * First the book is inputted into a nested if loop that makes sure that
     * the book is in the library's inventory. If true a flag is set to true.
     * Otherwise, it remains false. Then the flag is inputted into an if
     * loop. If the flag is true then the book is returned and then a counter
     * keeps count of the number of books returned. If the flag is false then
     * it prints out "Book not in the inventory".
     *
     * @param bookIssued
     */
    public void returnBook(String bookIssued){
        boolean back = false;
        for (int i = 0; i < tracker; i++) {

            if (bookIssued.equalsIgnoreCase(libraryInventory[i].getBookTitle())) {
                this.book = libraryInventory[i];
                back = true;
            }
        }
        if (back) {
            this.book.setIssueBook(false);
            returned++;
        }else {
            System.out.println("Book not in the inventory. Cannot take return!");
        }
    }

    /**
     * This method prints the list of available books.
     *
     * The for loop cycles through the library's inventory, and the if
     * loop sees if any book has been issued. If so, then it is not set into
     * the string variable. The returned variable holds the available list.
     *
     * @return available
     */
    public String printAvailableBooks(){
        String available = "";
        for (int i = 0; i < tracker; i++) {
            if (!libraryInventory[i].getIssueBook()) {
                available +=  libraryInventory[i].getBookTitle() + "\n";

            }
        }
        return available;

    }

    /**
     * This method returns the inventory's count.
     *
     * @return tracker
     */
    public int getInventoryCount() {
        return tracker;
    }

    /**
     * This method returns the current count of issued books.
     *
     * @return count returned
     */
    public int getNumberOfIssuedBooks() {
        return count - returned;
    }
}
