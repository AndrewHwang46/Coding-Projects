package tcss143.NWDashboard;

import java.util.ArrayList;

/**
 * @author Andrew Hwang
 * 6/3/2023
 * This class creates the network object byu instatiating two feilds. One String
 * which is the name of the network. And an arraylist which holds the shows in
 * the network. This class is used in Dashboard and DBScanner.
 * @version 1
 */
public class Network {
    private String nameOfNetwork;
    private ArrayList<Show> shows;

    /**
     * This method creates the network object by passing the name of the
     * network. As well as, creating a new arraylist for every time a new
     * network is created.
     * @param nameOfNetwork is a String and is the name of the network.
     */
    public Network(String nameOfNetwork) {
        shows = new ArrayList<>();
        this.nameOfNetwork = nameOfNetwork;
    }

    /**
     * This method allows you to get the name of the network.
     * @return
     * The return is a String and is the name of the network.
     */
    public String getNameOfNetwork() {
        return nameOfNetwork;
    }
    /**
     * This method allows you to get the shows in the network.
     * @return
     * The return is a String and is the shows in the network.
     */
    public ArrayList<Show> getShows() {
        return shows;
    }

    /**
     * This method allows you to add shows into the arraylist.
     * @param show is a Show and the show you want to add.
     */
    public void addShow(Show show) {
         shows.add(show);
     }

    /**
     * This method allows you to remove a show from the arraylist.
     * @param show is a Show and is the show you want to remove.
     */
     public void removeShow(Show show) {
        for (int i = 0; i > shows.size(); i++) {
            if (shows.get(i) == show) {
                shows.remove(show);
            }
        }
     }
    /**
     * This method allows you to format the network.
     * @return
     * The return is a String and is the formatted network.
     */
     @Override
    public String toString() {
        return nameOfNetwork;
     }
}

