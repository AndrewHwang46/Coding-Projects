package tcss143.NWDashboard;

import java.util.Comparator;

/**
 * @author Andrew Hwang
 * 6/3/2023
 * This class creates a new compare method.
 *
 * @version 1
 */
public class Compare implements Comparator<Show> {
    /**
     * This method creates a new comparing method. It orders the given show by
     * ascending numerical order, and when there is a tie it compares the
     * natural order of the title.
     * @param o1 the first object to be compared.
     * @param o2 the second object to be compared.
     * @return The return is an int and is whether the show1 is larger or
     * smaller than show2
     */
    @Override
    public int compare(Show o1, Show o2) {
        int compareRating = 0;
        if (o1.getTRP() > o2.getTRP()) {
            compareRating = 1;
        } else if (o1.getTRP() < o2.getTRP()) {
            compareRating = -1;
        } else if (o1.getTRP() == o2.getTRP()) {
            return o1.getNameOfShow().compareTo(o2.getNameOfShow());
        }
        return compareRating;
    }
}
