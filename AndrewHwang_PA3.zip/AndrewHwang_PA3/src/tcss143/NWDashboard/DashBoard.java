package tcss143.NWDashboard;

import java.util.*;

/**
 * @author Andrew Hwang
 * 6/3/2023
 * This class creates teh DashBoard. This is where all the methods from the
 * interface gets the logic and is able to run.
 *
 * @version 1
 */
public class DashBoard implements DashboardInterface{


    private Database database;

    /**
     * This method creates the dashboard object by passing in a database.
     * @param database The Database object to be associated with the Dashboard.
     */
    public DashBoard(Database database) {
        this.database = database;
    }

    /**
     * This method checks if the given show is in the list of all shows.
     * @param show The show to be checked for existence
     * @return The return is a boolean and shows whether the show is in
     * the list or not.
     */
    @Override
    public boolean doesShowExist(Show show) {
        return database.getShowSet().contains(show);
    }

    /**
     * This method checks the database if the given show is in multiple networks.
     * It searches the map to see if in each network the show is present. If it
     * is, then it increments a counter. If the counter is greater than 1 then
     * it returns true and if not, it returns false.
     * @param show The show to be checked for multiple existence.
     * @return The return is a boolean and shows whether the show is in
     * multiple networks or not.
     */
    @Override
    public boolean isShowInMultipleNetworks(Show show) {
        int count = 0;
        for(Network network : database.getNetworkShowMap().keySet()) {
            ArrayList<Show> showsInNetwork =
                    new ArrayList<>(database.getNetworkShowMap().get(network));
            for (Show value : showsInNetwork) {
                if (value.equals(show)) {
                    count++;
                }
            }
        }

        return count > 1;
    }

    /**
     * This method orders the showSet by the compareTo method in the show class.
     * @return The return is a String and is the ordered list.
     */
    @Override
    public String showsOrderedByGenreAndName() {
        String list = "";
        Iterator<Show> itr = database.getShowSet().iterator();
        ArrayList<Show> orderedShows = new ArrayList<>(database.getShowSet());
        Collections.sort(orderedShows);
        while(itr.hasNext()) {
            Show searchingShow = itr.next();
            list += String.valueOf(searchingShow) + "\n";
        }
        return list;
    }

    /**
     * This method orders the showSet by ascending order with the TPR. Then
     * retrieves the shows with the lowest and highest TPR.
     * @return The return is a String and is the shows with the highest and
     * lowest TPR.
     */
    @Override
    public String getShowsWithMinAndMaxTRP() {
        ArrayList<Show> showList = new ArrayList<>(database.getShowSet());
        Collections.sort(showList, new Compare());
        Show minTrp = showList.get(0);
        Show maxTrp = showList.get(showList.size()-1);
        return "MaxTRP - " + maxTrp + "\n" + "MinTRP - " + minTrp;

    }

    /**
     * This method checks if the given show is in the given network. This method
     * must first sort the list of shows in the specific number. Then it
     * preforms the binary search.
     * @param network The network to search within.
     * @param show The network to search within.
     * @return The return is a boolean and is whether the show is in the
     * given network or not.
     */
    @Override
    public boolean findShowInNetwork(Network network, Show show) {
        boolean flag = true;
        ArrayList<Show> networkShowList = database.getNetworkShowMap().get(network);
        Collections.sort(networkShowList);
        int x = Collections.binarySearch(networkShowList, show);
        if (x < 0) {
            flag = false;
        }
        return flag;
    }

    /**
     * This method gets the show with the lowest TPR in the given network.
     * First, it sorts the list of shows in the given network in acceding
     * numerical order. Then it retrieves the show with the lowest TPR in the
     * network.
     * @param network The network to search within
     * @return The return is a String and is the show with the lowest TPR.
     */
    @Override
    public String findShowInNetworkWithMinTRP(Network network) {
        ArrayList<Show> networkShowList1 = database.getNetworkShowMap().get(network);
        Collections.sort(networkShowList1, new Compare());
        Show minTrp = networkShowList1.get(0);
        return minTrp.toString();
    }

    /**
     * This method gets the show with the highest TPR in the given network.
     * First, it sorts the list of shows in the given network in acceding
     * numerical order. Then it retrieves the show with the highest TPR in the
     * network.
     * @param network The network to search within
     * @return The return is a String and is the show with the highest TPR.
     */
    @Override
    public String findShowInNetworkWithMaxTRP(Network network) {
        ArrayList<Show> networkShowList2 = database.getNetworkShowMap().get(network);
        Collections.sort(networkShowList2, new Compare());
        Show maxTrp = networkShowList2.get(networkShowList2.size()-1);
        return maxTrp.toString();
    }
}
