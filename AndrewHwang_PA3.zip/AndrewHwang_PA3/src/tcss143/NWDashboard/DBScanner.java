package tcss143.NWDashboard;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * @author Andrew Hwang
 * 6/3/2023
 * This method creates the DBScanner.This class is used in the DashBoard.
 *
 * @version 1
 */
public class DBScanner {

    private Database database;

    /**
     * This method creates the DBScanner object with the specific absolute
     * path of the file.
     * @param absolutePathOfFile The absolute path of the file to be
     *                           scanned and used to create the database.
     */
    public DBScanner(String absolutePathOfFile) {
        this.database = new Database();
        this.createDatabase(absolutePathOfFile);
    }

    /**
     * This method gets the database.
     * @return The return is a database and is the database.
     */
    public Database getDatabase() {
        return database;
    }

    /**
     * This method reads a file using a BufferedReader and gets the position of
     * the networks and adds them into the networkSet and networkShowMap. As
     * well as, gets the position of every show and adds them one by one into
     * the showSet and networkShowSet.
     * @param absolutePathOfFile The absolute path of the file to be
     *                           scanned and used to create the database.
     */
    public void createDatabase(String absolutePathOfFile) {
        try (BufferedReader br = new BufferedReader(new FileReader(absolutePathOfFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String nameNetwork = line.substring(0, line.indexOf(":"));
                Network network = new Network(nameNetwork);
                database.addNetwork(network);

                String[] listOfShows = line.substring(line.indexOf(":") + 1).split(";");
                for (String indexOfShow : listOfShows) {
                    //ArrayList<Show> showList = new ArrayList<>();
                    String[] tvShow = indexOfShow.split(",");
                    String nameOfShow = tvShow[0];
                    Genre genre = Genre.valueOf(tvShow[1]);
                    double TRP = Double.parseDouble(tvShow[2]);

                    Show show = new Show(nameOfShow, genre, TRP);

                    database.addShow(show);
                    database.mapShowToNetwork(network, show);


                    }
                }
            } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
