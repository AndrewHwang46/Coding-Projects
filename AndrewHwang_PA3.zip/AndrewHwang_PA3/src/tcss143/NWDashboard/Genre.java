package tcss143.NWDashboard;

/**
 * @author Andrew Hwang
 * 6/3/2023
 * This class creates the values of Genre and allows ease of adding or removing genres.
 * @version 1
 */
public enum Genre {
    COMEDY,DRAMA,EPIC,SCIFI,ROMANCE,THRILLER,DOCUMENTARY,HORROR,ANIMATION,FANTASY
}
