package tcss143.NWDashboard;

// NOTE: It is helpful to create comparator classes
// so that you can reuse them
public interface DashboardInterface {


    //use of sets
    public boolean doesShowExist(Show show);

    //use of maps
    public boolean isShowInMultipleNetworks(Show show);

    // use of sorting -
    // first order by Genre
    //break ties with Name
    // print list of shows each in new line
    public String showsOrderedByGenreAndName();

    // use of sorting, comparable
    // Compare shows with each other based on TRP
    // You can modify show to implement compareTo method.
    // This method outputs the show with highest TRP
    // and Lowest TRP.
    // The format is "MaxTRP - Show{...} \n
    //                MinTRP - Show{...}"
    public String getShowsWithMinAndMaxTRP();

    //binarySearch, natural sorting
    // Find the show in a given network.
    // use comparator if required
    public boolean findShowInNetwork(Network network, Show show);

    // Implement below methods by first sorting using comparator
    //Then use same comparator to search.

    //binarySearch, comparator
    public String findShowInNetworkWithMinTRP(Network network);

    //binarySearch, comparator sorting
    public String findShowInNetworkWithMaxTRP(Network network);

}