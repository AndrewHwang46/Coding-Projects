package tcss143.NWDashboard;

import java.util.*;

/**
 * @author Andrew Hwang
 * 6/3/2023
 * This class is where all the methods created in dashboard is called.
 *
 * @version 1
 */

public class ClientMenu {
    /**
     * This method is where the menu is created and preformed.
     * @param args Command-line arguments.
     * @throws Exception if an error occurs during program execution
     */
    public static void main(String[] args)  {
        DBScanner dbScanner = new DBScanner("C:\\Users\\andre\\IdeaProjects\\PA3\\src\\input.txt");
        DashBoard dash = new DashBoard(dbScanner.getDatabase());
        boolean exiter = false;

        Scanner scanner = new Scanner(System.in);
        System.out.println("Menu");

        while(!exiter) {
            System.out.println("Select a choice from the menu:");
            System.out.println("1. Displays if the show is in the list.");
            System.out.println("2. Displays if the show is in multiple networks.");
            System.out.println("3. Displays all the shows in the list.");
            System.out.println("4. Displays the show with the highest and lowest TRP scores");
            System.out.println("5. Displays if the show is in a specific network.");
            System.out.println("6. Displays the lowest TRP show in a given network.");
            System.out.println("7. Displays the highest TRP show in a given network.");
            System.out.println("8. Exits program.");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> {
                    System.out.println("Please Enter A Show.");
                    String userShow = scanner.next();

                    Show showName = showName(dbScanner, userShow);
                    System.out.println(showName != null && dash.doesShowExist(showName));
                }
                case 2 -> {
                    System.out.println("Enter A Show.");
                    String userShow = scanner.next();

                    Show showName = showName(dbScanner, userShow);
                    System.out.println(showName != null && dash.isShowInMultipleNetworks(showName));
                }
                case 3 -> System.out.println("\n" + dash.showsOrderedByGenreAndName());
                case 4 -> System.out.println("\n" + dash.getShowsWithMinAndMaxTRP());
                case 5 -> {
                    System.out.println("Enter A Network. \n");
                    String userNetwork = scanner.next();
                    System.out.println("Enter A Show. ");
                    String userShow = scanner.next();

                    Network networkName = getNetworkFromDatabase(dbScanner, userNetwork);
                    Show showName = showName(dbScanner, userShow);

                    if (networkName == null) {
                        System.out.println("Invalid Network. \n");
                    }

                    if (showName == null) {
                        System.out.println("Invalid Show. \n");
                    }
                    System.out.println(dash.findShowInNetwork(networkName, showName));
                }
                case 6 -> {
                    System.out.println("Enter A Network. \n");
                    String userNetwork = scanner.next();

                    Network networkName = getNetworkFromDatabase(dbScanner, userNetwork);

                    if (networkName != null) {
                        System.out.println(dash.findShowInNetworkWithMinTRP(networkName));
                    } else {
                        System.out.println("Invalid Network. \n");
                    }
                }
                case 7 -> {
                    System.out.println("Enter A Network.\n");
                    String userNetworkName = scanner.next();

                    Network networkName = getNetworkFromDatabase(dbScanner, userNetworkName);

                    if (networkName != null) {
                        System.out.println(dash.findShowInNetworkWithMaxTRP(networkName));
                    } else {
                        System.out.println("Invalid Network. \n");
                    }
                }
                case 8 -> {
                    exiter = true;
                    System.out.println("Goodbye!");
                }
                default -> System.out.println("Please enter a valid choice.");
            }
        }
    }

    /**
     * This method retrieves the Show from the database from the given show name.
     * @param dbScanner The DBScanner object used to access the database.
     * @param showName The name of the show to retrieve.
     * @return The return is a Show and is the Show of the given show name.
     */
    public static Show showName(DBScanner dbScanner, String showName) {

        Iterator<Show> itr = dbScanner.getDatabase().getShowSet().iterator();

        while(itr.hasNext()){
            Show show = itr.next();
            if (show.getNameOfShow().equals(showName)) {
                return show;
            }
        }

        return null;
    }

    /**
     * This method retrieves the Network from the database from the given
     * network name.
     * @param dbScanner The DBScanner object used to access the database.
     * @param name The name of the network to retrieve.
     * @return The return is a Network and is the Show of the given
     * network name.
     */
    public static Network getNetworkFromDatabase(DBScanner dbScanner, String name) {
        Network network = null;
        Set<Network> networkSet = dbScanner.getDatabase().getNetworkSet();
        for (Network n : networkSet) {
            if (n.getNameOfNetwork().equals(name)) {
                network = n;
                break;
            }
        }
        return network;
    }
}