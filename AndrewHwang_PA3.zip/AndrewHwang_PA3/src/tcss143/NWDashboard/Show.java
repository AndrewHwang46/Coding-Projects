package tcss143.NWDashboard;

/**
 * @author Andrew Hwang
 * 6/3/2023
 * This class creates the Show object by instatiating three feilds. One being
 * a string and the name of the show. The next being an Enum/Genre and the genre
 * of the show. Lastly a double and the TRP. Show is used in Network,
 * Database, and DBScanner.
 *
 * @version 1
 */
public class Show implements Comparable<Show> {
    private String nameOfShow;
    private Genre genre;
    private double TRP;

    /**
     * This method creates the show object by passing a String, Enum,
     * and a double.
     * @param nameOfShow The param is a String and the name of the show.
     * @param genre The param is an Enum/Genre and is the genre of the show.
     * @param TRP The param is a double and is the TRP.
     */
    public Show (String nameOfShow, Genre genre, double TRP) {
        this.nameOfShow = nameOfShow;
        this.genre = genre;
        this.TRP = TRP;
    }

    /**
     * This method allows you to get the name of the show.
     * @return
     * The return is a String and the name of the show.
     */
    public String getNameOfShow() {
        return nameOfShow;
    }

    /**
     * This method allows you to get the TRP.
     * @return
     * The return is a double and is the TRP of the show.
     */
    public double getTRP() {
        return TRP;
    }

    /**
     * This method allows you to get the genre.
     * @return
     * The return is a Genre and is the genre of the show.
     */
    public Genre getGenre() {
        return genre;
    }

    /**
     * This method allows you to format the show in nameOfShow, genre,
     * TRP order.
     * @return
     * The return is a String and is the formatted show.
     */
    public String toString() {
        return "Name of the show: " + nameOfShow + "\n Genre: " + genre + "\n TRP: " + TRP + "\n";
    }

    /**
     * This method compares two shows together by the genre of the show. If
     * there is a tie between the genres then it breaks the tie by the name
     * of the show.
     * @param show the object to be compared.
     * @return The return is an int and shows whether it is true, false or
     * equal to.
     */
    @Override
    public int compareTo(Show show) {
        int x = 0;
        if(this.genre.compareTo(show.getGenre()) > 0)  {
            x = 1;
        }else if(this.genre.compareTo(show.getGenre()) < 0){
            x = -1;

        }else if(this.genre == show.getGenre()) {
            return this.nameOfShow.compareTo(show.getNameOfShow());
        }
        return x;

    }

    /**
     * This method compares two shows to see if they are equal to each other,
     * by comparing their names, genres, and TRP.
     * @param o is the object to be compared
     * @return The return is a boolean and shows if they are equal to or not.
     */
    @Override
    public boolean equals(Object o) {

        if (o instanceof Show otherShow) {
            return this.nameOfShow.equals(otherShow.nameOfShow) &&
                    this.genre.equals(otherShow.genre) && this.TRP == otherShow.TRP;
        } else {
            return false;
        }

    }
}
