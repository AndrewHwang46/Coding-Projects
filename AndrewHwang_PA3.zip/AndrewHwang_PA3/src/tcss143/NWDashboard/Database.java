package tcss143.NWDashboard;

import java.util.*;

/**
 * @author Andrew Hwang
 * 6/3/2023
 * This class creates the database. It stores the list of shows and networks
 * in set and maps repectively. This class is used in DBScanner and DashBoard.
 * @version 1
 */
public class Database {

    private Set<Network> networkSet;
    private Set<Show> showSet;
    private Map<Network, ArrayList<Show>> networkShowMap;

    /**
     * This method creates the database class by creating new network and show
     * sets everytime the database is made. As well as, the network show map.
     */
    public Database() {
        this.networkSet = new HashSet<Network>();
        this.showSet = new HashSet<Show>();
        this.networkShowMap = new HashMap<>();
    }

    /**
     * This method adds new networks in the network set. As well ass, adding
     * the network into the map as a key and adding the shows in the network
     * as the value.
     * @param network is a Network and is the network you want to add into the
     *                set and map.
     */
    public void addNetwork(Network network) {
        networkSet.add(network);
        networkShowMap.put(network, network.getShows());
    }

    /**
     * This method adds the show into the set if it is not already present.
     * @param show The show to be added.
     */
    public void addShow(Show show) {
        Set<Show> listOfShow = new HashSet<>(showSet);

        for (Show currentShow : listOfShow) {
            if (currentShow.equals(show)) {
                return;
            }
        }
        showSet.add(show);

    }

    /**
     * This method adds a network and the show into the map. If the network
     * already exist in the map then it adds the show into the existing list.
     * If it does not then it creates a new entry.
     * @param network The network to which the show will be mapped.
     * @param show The show to be mapped to the network.
     */
    public void mapShowToNetwork(Network network, Show show) {

        ArrayList<Show> networkListShows = networkShowMap.get(network);
        networkListShows.add(show);
        networkShowMap.put(network, networkListShows);

    }

    /**
     * This method gets the showSet.
     * @return The return is a set and is the showSet.
     */
    public Set<Show> getShowSet() {
        return showSet;
    }

    /**
     * This method gets the networkSet.
     * @return The return is a set and is the networkSet.
     */
    public Set<Network> getNetworkSet() {
        return networkSet;
    }

    /**
     * This method gets the networkShowMap.
     * @return The return is a map and is the networkShowMap.
     */
    public Map<Network, ArrayList<Show>> getNetworkShowMap() {
        return networkShowMap;
    }

}
